package com.example.iajugadora

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Un dedo: va de (x,y) a (toX,toY) empezando en startMs y durando durMs. Coordenadas en píxeles. */
class Touch(val x: Float, val y: Float, val toX: Float, val toY: Float, val startMs: Long, val durMs: Long)

/** Ejecuta varios dedos a la vez (sticks + botones del mando táctil del juego). */
class GameAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: GameAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun play(touches: List<Touch>) {
        if (touches.isEmpty()) return
        val b = GestureDescription.Builder()
        for (t in touches.take(10)) {
            val p = Path().apply { moveTo(t.x, t.y); lineTo(t.toX, t.toY) }
            b.addStroke(GestureDescription.StrokeDescription(p, t.startMs, t.durMs))
        }
        dispatchGesture(b.build(), null, null)
    }
}
