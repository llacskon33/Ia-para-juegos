package com.example.iajugadora

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Estado compartido entre el servicio y la pantalla. */
object AgentState {
    var running by mutableStateOf(false)
    var log by mutableStateOf("")
}
