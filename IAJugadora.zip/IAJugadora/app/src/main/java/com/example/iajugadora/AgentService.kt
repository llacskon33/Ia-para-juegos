package com.example.iajugadora

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.hypot

class Controls(
    val left: Triple<Float, Float, Float>?,   // x, y, radio (normalizados)
    val right: Triple<Float, Float, Float>?,
    val buttons: Map<String, Pair<Float, Float>>
)

class Step(
    val holdMs: Long,
    val left: Pair<Float, Float>?,
    val right: Pair<Float, Float>?,
    val press: List<String>,
    val pressAt: Long
)

/**
 * Tres hilos que trabajan a la vez:
 *  1) Captura: guarda un fotograma nuevo como máximo cada 50 ms.
 *  2) Cerebro: Gemini identifica el juego y los controles, y después devuelve planes de pasos.
 *  3) Ejecutor: cada paso del último plan se toca en la pantalla sin esperar a la IA.
 */
class AgentService : Service() {

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var frameThread: HandlerThread? = null
    private var curW = 0
    private var curH = 0
    @Volatile private var realW = 0
    @Volatile private var realH = 0
    @Volatile private var lastJpeg: ByteArray? = null
    @Volatile private var lastFrameAt = 0L
    @Volatile private var active = false
    @Volatile private var controls: Controls? = null
    @Volatile private var plan: List<Step> = emptyList()
    @Volatile private var planVersion = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (active) return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ch", "IA Jugadora", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, AgentService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, "ch")
            .setContentTitle("La IA está jugando")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Parar", stop).build())
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))
        }

        frameThread = HandlerThread("frames").also { it.start() }
        active = true
        AgentState.running = true
        AgentState.log = "Iniciando…"
        Thread { brain() }.start()
        Thread { executor() }.start()
        return START_NOT_STICKY
    }

    // ---------- 1) CAPTURA (cada 50 ms) ----------

    @Synchronized
    private fun ensureCapture() {
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        realW = dm.widthPixels
        realH = dm.heightPixels
        val w = realW / 2
        val h = realH / 2
        if (w == curW && h == curH) return
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ onFrame(it) }, Handler(frameThread!!.looper))
        reader = r
        val v = vd
        if (v == null) {
            vd = projection?.createVirtualDisplay(
                "cap", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            v.resize(w, h, dm.densityDpi)
            v.surface = r.surface
        }
        curW = w
        curH = h
    }

    private fun onFrame(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameAt < 50) return
            lastFrameAt = now
            val p = img.planes[0]
            val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer)
            val crop = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
            val out = ByteArrayOutputStream()
            crop.compress(Bitmap.CompressFormat.JPEG, 70, out)
            lastJpeg = out.toByteArray()
        } catch (e: Exception) {
        } finally {
            img.close()
        }
    }

    // ---------- 2) CEREBRO (Gemini) ----------

    private fun parseControls(j: JSONObject): Controls? {
        val c = j.optJSONObject("controls") ?: return null
        fun stick(n: String): Triple<Float, Float, Float>? {
            val s = c.optJSONObject(n) ?: return null
            return Triple(s.getDouble("x").toFloat(), s.getDouble("y").toFloat(), s.optDouble("r", 0.1).toFloat())
        }
        val b = HashMap<String, Pair<Float, Float>>()
        c.optJSONObject("buttons")?.let { o ->
            for (k in o.keys()) {
                val a = o.optJSONArray(k)
                if (a != null && a.length() == 2) b[k.uppercase()] = Pair(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
            }
        }
        val l = stick("left")
        val r = stick("right")
        if (l == null && r == null && b.isEmpty()) return null
        return Controls(l, r, b)
    }

    private fun dir(a: JSONArray?): Pair<Float, Float>? =
        if (a != null && a.length() == 2) Pair(a.getDouble(0).toFloat(), a.getDouble(1).toFloat()) else null

    private fun brain() {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        var lastReason = "ninguno"
        var game = "desconocido"
        while (active) {
            val t0 = System.currentTimeMillis()
            try {
                if (GameAccessibilityService.instance == null) {
                    AgentState.log = "Activa el servicio de accesibilidad de IA Jugadora."
                    Thread.sleep(2000); continue
                }
                ensureCapture()
                val jpeg = lastJpeg
                if (jpeg == null) { Thread.sleep(300); continue }

                val key = prefs.getString("key", "") ?: ""
                val model = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
                val goal = prefs.getString("goal", "") ?: ""
                val c = controls

                if (c == null) {
                    val prompt = """
                        Mira esta captura de un juego móvil que tiene controles táctiles tipo mando de Xbox superpuestos.
                        1) Identifica el juego. 2) Localiza los controles táctiles visibles.
                        Coordenadas normalizadas 0-1 (origen arriba-izquierda). El radio de los sticks es fracción del lado corto de la pantalla.
                        Responde SOLO JSON: {"game":"nombre o desconocido","controls":{"left":{"x":0,"y":0,"r":0},"right":{"x":0,"y":0,"r":0},"buttons":{"A":[x,y],"B":[x,y],"X":[x,y],"Y":[x,y],"LB":[x,y],"RB":[x,y],"LT":[x,y],"RT":[x,y],"UP":[x,y],"DOWN":[x,y],"LEFT":[x,y],"RIGHT":[x,y],"START":[x,y]}}}
                        Omite lo que no veas. Si no hay controles visibles pon "controls":null.
                    """.trimIndent()
                    val j = JSONObject(GeminiClient.ask(key, model, prompt, jpeg))
                    game = j.optString("game", "desconocido")
                    val parsed = parseControls(j)
                    if (parsed != null) {
                        controls = parsed
                        AgentState.log = "Juego: $game. Controles detectados: ${parsed.buttons.keys.joinToString()}"
                    } else {
                        AgentState.log = "Juego: $game. No veo los controles; abre el juego con el mando en pantalla."
                    }
                } else {
                    val desc = buildString {
                        append("Stick izquierdo: ").append(if (c.left != null) "sí" else "no")
                        append(". Stick derecho: ").append(if (c.right != null) "sí" else "no")
                        append(". Botones: ").append(c.buttons.keys.joinToString())
                    }
                    val prompt = """
                        Eres un jugador experto del juego "$game". Controlas el mando táctil superpuesto viendo una captura de pantalla.
                        Objetivo: ${if (goal.isBlank()) "avanzar y superar el nivel" else goal}
                        Controles disponibles: $desc.
                        Responde SOLO JSON: {"reason":"breve","plan":[{"hold_ms":100..1500,"left":[dx,dy] o null,"right":[dx,dy] o null,"press":["A","RB"],"press_at_ms":0}]}
                        dx,dy entre -1 y 1 (dx>0 derecha, dy>0 abajo). "press" son botones a pulsar en ese paso.
                        Máximo 8 pasos y que sumen como mucho 6000 ms: se ejecutan mientras piensas el siguiente plan.
                        Si ves un menú o diálogo, usa solo "press" con los botones adecuados.
                        Razón del plan anterior: $lastReason
                    """.trimIndent()
                    val j = JSONObject(GeminiClient.ask(key, model, prompt, jpeg))
                    lastReason = j.optString("reason", "")
                    AgentState.log = "Juego: $game · $lastReason"
                    val arr = j.optJSONArray("plan") ?: JSONArray()
                    val steps = ArrayList<Step>()
                    for (i in 0 until minOf(arr.length(), 8)) {
                        val s = arr.getJSONObject(i)
                        val pr = ArrayList<String>()
                        s.optJSONArray("press")?.let { a -> for (k in 0 until a.length()) pr.add(a.getString(k)) }
                        steps.add(
                            Step(s.optLong("hold_ms", 400).coerceIn(100, 1500), dir(s.optJSONArray("left")),
                                dir(s.optJSONArray("right")), pr, s.optLong("press_at_ms", 0))
                        )
                    }
                    plan = steps
                    planVersion++
                }
            } catch (e: Exception) {
                AgentState.log = "Error: ${e.message}"
                try { Thread.sleep(3000) } catch (_: InterruptedException) { break }
            }
            // Mínimo 4 s entre llamadas por el límite de la clave gratuita
            val rest = 4000 - (System.currentTimeMillis() - t0)
            if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { break }
        }
    }

    // ---------- 3) EJECUTOR ----------

    private fun executor() {
        var seen = 0
        var steps: List<Step> = emptyList()
        var idx = 0
        while (active) {
            try {
                if (planVersion != seen) { seen = planVersion; steps = plan; idx = 0 }
                val svc = GameAccessibilityService.instance
                val c = controls
                if (svc == null || c == null || idx >= steps.size) { Thread.sleep(50); continue }
                val s = steps[idx++]

                val short = minOf(realW, realH).toFloat()
                val touches = ArrayList<Touch>()
                fun stick(st: Triple<Float, Float, Float>?, d: Pair<Float, Float>?) {
                    if (st == null || d == null) return
                    val len = hypot(d.first, d.second)
                    if (len < 0.05f) return
                    val ux = d.first / len
                    val uy = d.second / len
                    val cx = st.first * realW
                    val cy = st.second * realH
                    val r = st.third * short
                    touches.add(Touch(cx + ux * r * 0.5f, cy + uy * r * 0.5f, cx + ux * r, cy + uy * r, 0, s.holdMs))
                }
                stick(c.left, s.left)
                stick(c.right, s.right)
                val start = s.pressAt.coerceIn(0, maxOf(s.holdMs - 100, 0))
                for (name in s.press) {
                    val p = c.buttons[name.uppercase()] ?: continue
                    val x = p.first * realW
                    val y = p.second * realH
                    touches.add(Touch(x, y, x + 1f, y, start, 80))
                }
                svc.play(touches)
                Thread.sleep(s.holdMs)
            } catch (e: Exception) {
                try { Thread.sleep(100) } catch (_: InterruptedException) { break }
            }
        }
    }

    override fun onDestroy() {
        active = false
        AgentState.running = false
        vd?.release()
        reader?.close()
        projection?.stop()
        frameThread?.quitSafely()
        super.onDestroy()
    }
}
