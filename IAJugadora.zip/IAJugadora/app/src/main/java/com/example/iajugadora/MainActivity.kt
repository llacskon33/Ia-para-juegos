package com.example.iajugadora

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            startForegroundService(
                Intent(this, AgentService::class.java).putExtra("code", r.resultCode).putExtra("data", d)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        setContent { MaterialTheme { Screen(prefs) } }
    }

    @Composable
    private fun Screen(prefs: SharedPreferences) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var model by remember { mutableStateOf(prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash") }
        var goal by remember { mutableStateOf(prefs.getString("goal", "") ?: "") }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("IA Jugadora", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(),
                label = { Text("Clave de Google AI Studio (Gemini)") },
                visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Modelo") })
            OutlinedTextField(goal, { goal = it }, Modifier.fillMaxWidth(),
                label = { Text("Objetivo (opcional)") })

            Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                Text("1. Activar accesibilidad")
            }
            Button(enabled = !AgentState.running, onClick = {
                prefs.edit().putString("key", key.trim()).putString("model", model.trim())
                    .putString("goal", goal).apply()
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projLauncher.launch(mpm.createScreenCaptureIntent())
            }) { Text("2. Iniciar IA (luego abre el juego)") }
            OutlinedButton(onClick = {
                startService(Intent(this@MainActivity, AgentService::class.java).setAction("STOP"))
            }) { Text("Parar") }

            Text(if (AgentState.running) "Estado: jugando" else "Estado: parada")
            Text(AgentState.log)
        }
    }
}
